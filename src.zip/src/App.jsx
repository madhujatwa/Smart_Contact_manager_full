export default function App() {
  return (
    <h1 style={{ color: "red", fontSize: "50px" }}>
      Hello React
    </h1>
  );
}